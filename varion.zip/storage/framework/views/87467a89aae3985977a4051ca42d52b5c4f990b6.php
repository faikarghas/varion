
<?php $__env->startSection('content'); ?>
<div class="h_aks1"></div>
        <header class="position-relative">
            
            <?php echo $__env->make('components/presentational/menu',['listMenu'=>$listMenu], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="slider__header">
                <ul class="aboutHeaderSlider">
                    <li class="aboutHeaderSlider-item">
                        <div class="left-img"><img src="<?php echo e(asset('images')); ?>/<?php echo e($imageHeader1); ?>" alt="fume-img1" width="100%">
                            <div class="desc"><h4><?php echo $titleHeader; ?></h4></div>
                        </div>
                        
                    </li>
                </ul>
            </div>
            <div class="bg-headerAbout"></div>
            <div class="bg-headerAbout2"></div>
            <div class="h_aks2"></div>
        </header>
        <main>
            <section class="section__subsidiaries-first">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <h4><?php echo e($name); ?></h4>
                        </div>
                        <div class="col-12 col-lg-7">
                            <div class="img__wrapper">
                                <div class="img__wrapper-front"><img src="<?php echo e(asset('images')); ?>/<?php echo e($imageFront); ?>" width="100%" height="100%" alt=""></div>
                                <div class="img__wrapper-back"><img src="<?php echo e(asset('images')); ?>/<?php echo e($imageBack); ?>" width="100%" height="100%"     alt=""></div>
                            </div>
                        </div>
                        <div class="col-12 col-lg-5">
                            <h3><?php echo e($title); ?></h3>
                            <?php echo $description; ?>

                        </div>
                    </div>
                </div>
                <div class="bg-mainSubsiFirst"></div>
                <div class="bg-mainSubsiFirst2"></div>
            </section>
            <section class="section__subsidiaries-second">
                <div class="container">
                    <div class="row">
                        <div class="col-12 col-lg-4 mb-5">
                            <div class="img__wrapper">
                                <img src="<?php echo e(asset('images')); ?>/<?php echo e($imageInvestment); ?>" width="100%" height="100%" alt="">
                            </div>
                            <div class="desc__wrapper">
                                <?php if($slug ===  'pt-varion-sukses-makmur'): ?>
                                    <h3 class="mb-4">PLANTATION</h3>
                                    <p>Generally planted in large beds in shaded nurseries, coffee seeds will be watered frequently and shaded from the bright sunlight until they show heartiness in order for them to be permanently planted. Often, planting takes place during the rainy season as they need the moist soil to be firmly growing.</p>
                                <?php elseif($slug ===  'pt-varion-agritech-indonesia'): ?>
                                    <h3 class="mb-4">RESEARCH & DEVELOPMENT</h3>
                                    <p>This is where our innovations and future breakthroughs are born. We strive to put consistent research and development as a top priority in order to keep serving people the best of our products and services. </p>
                                <?php else: ?>
                                    <h3 class="mb-4">RESEARCH & DEVELOPMENT</h3>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-12 col-lg-4 mb-5">
                            <div class="img__wrapper">
                                <img src="<?php echo e(asset('images')); ?>/<?php echo e($imageBusiness); ?>" width="100%" height="100%" alt="">
                            </div>
                            <div class="desc__wrapper">
                                <?php if($slug ===  'pt-varion-sukses-makmur'): ?>
                                    <h3 class="mb-4">PROCESSING</h3>
                                    <p>After the coffee-picking, processing must begin immediately before the fruits become spoiled. In the processing step, the coffee bean is done in two famous ways depending on the weather, which are dry and wet methods.   </p>
                                <?php elseif($slug ===  'pt-varion-agritech-indonesia'): ?>
                                    <h3 class="mb-4">STRAWBERRY FARMING</h3>
                                    <p>Strawberry production in Japan is mostly done in greenhouses due to the uncertain temperatures, water, and conditions. Bringing those strawberries to tropical land like Indonesia has become the better decision since the humidity stays in control. </p>
                                <?php else: ?>
                                    <h3 class="mb-4">FARMING</h3>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-12 col-lg-4 mb-5">
                            <div class="img__wrapper">
                                <img src="<?php echo e(asset('images')); ?>/<?php echo e($imageCapital); ?>" width="100%" height="100%" alt="">
                            </div>
                            <div class="desc__wrapper">
                                <?php if($slug ===  'pt-varion-sukses-makmur'): ?>
                                    <h3 class="mb-4">TRADING</h3>
                                    <p>Being the second most commonly traded commodity in the world with more than 2.25 billion cups consumed daily, coffee trails only as a source of foreign exchange to developing countries. </p>
                                <?php elseif($slug ===  'pt-varion-agritech-indonesia'): ?>
                                    <h3 class="mb-4">DISTRIBUTION</h3>
                                    <p>Strawberries are widely consumed as the fruit itself, jams, beverages, and other food flavorings. In the market, strawberry fruits are among the fancy fruits that many people often dig in because of the taste and health benefits. </p>
                                <?php else: ?>
                                    <h3 class="mb-4">DISTRIBUTION</h3>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="bg-mainSubsiSecond"></div>
            </section>
            <section class="section__subsidiaries-third">
                <?php if($imageFooterType === 1): ?>
                    <div class="banner_wrapper">
                        <div class="banner_wrapper-left" style="background-image: url('<?php echo e(asset('images')); ?>/<?php echo e($imageFooter); ?>')">
                            <div class="desc"><?php echo $imageFooterDesc; ?></div>
                        </div>
                        <div class="banner_wrapper-right" style="background-image: url('<?php echo e(asset('images')); ?>/<?php echo e($imageFooter2); ?>')">
                            <div class="desc"><?php echo $imageFooter2Desc; ?></div>
                            <div class="btn-readMore">
                                <a href="">READ MORE</a>
                            </div>
                        </div>
                    </div>
                <?php elseif($imageFooterType === 2): ?>
                <div class="banner_wrapper2">
                    <div class="banner_wrapper2-left" style="background-image: url('<?php echo e(asset('images')); ?>/<?php echo e($imageFooter); ?>')">
                        <div class="desc"><?php echo $imageFooterDesc; ?></div>
                    </div>
                    <div class="banner_wrapper2-right" style="background-image: url('<?php echo e(asset('images')); ?>/<?php echo e($imageFooter2); ?>')"></div>
                </div>
                <?php else: ?>
                    <div class="banner__subsidiaries" style="background-image: url('<?php echo e(asset('images')); ?>/<?php echo e($imageFooter); ?>')">
                        <div class="container">
                            <div class="row">
                                <div class="col-12">
                                    <div class="banner__subsidiaries-desc">
                                        <?php if($slug ===  'pt-varion-agritech-indonesia'): ?>
                                            <h2 class="mb-4">WILL BE ON THE<br> MARKET IN 2022</h2>
                                            <p>It is with great pleasure to announce to you that our finest strawberries are coming to your nearest supermarket soon.</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

            </section>
            <section class="section__subsidiaries-contact">
                <?php echo $__env->make('components/presentational/contact',[
                    'description'=>$descriptionCT,
                    'addressCT'=>$addressCT,
                    'phoneCT'=>$phoneCT,
                    'faxCT'=>$faxCT,
                    'emailCT'=>$emailCT
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </section>
        </main>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('components/layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ghass\Documents\Progamming\Work\varion\resources\views/v_subsidiaries.blade.php ENDPATH**/ ?>