<menu class="menu__home">
    <?php echo $__env->make('components/presentational/menuMobile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="menu__home-logo"><a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('/images/logo_black.png')); ?>" alt="" srcset=""  height="40px"></a></div>
    <div class="menu__home-link forDesktop-dflex">
        <ul>
            <li><a href="<?php echo e(route('home')); ?>">HOME</a></li>
            <li><a href="<?php echo e(route('about')); ?>">ABOUT US</a></li>
            <li class="dropdown_link">
                <a href="">SUBSIDIARIES</a>
                <ul class="sub__menu">
                    <?php $__currentLoopData = $listMenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(url('subsidiaries/'.$item->slug)); ?>"><?php echo e($item->name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </li>
            <li><a href="<?php echo e(route('contact')); ?>">CONTACT</a></li>
            <li><a href="<?php echo e(route('career')); ?>">CAREER</a></li>
        </ul>
    </div>
    <div class="menu__home-navbar forMobile">
        <ul>
            <li class="open_menu">
                <div id="menu-hamburger" class="">
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </li>
        </ul>
    </div>
</menu><?php /**PATH C:\Users\ghass\Documents\Progamming\Work\varion\resources\views/components/presentational/menu.blade.php ENDPATH**/ ?>