<div class="menu__mobileOverlay">
</div>

<div class="menu__mobile forMobile">
    <div class="menu__mobile-search">
        <form action="">
            <input type="text" name="" id="" placeholder="SEARCH...">
        </form>
    </div>
    <div class="menu__mobile-link">
        <ul>
            <li><a href="<?php echo e(route('about')); ?>">ABOUT</a></li>
            <li><a href="<?php echo e(route('career')); ?>">CAREER</a></li>
            <li><a href="<?php echo e(route('contact')); ?>">CONTACT</a></li>
            <li><a href="<?php echo e(url('subsidiaries/pt-varion-sukses-makmur')); ?>">PT VARION SUKSES MAKMUR</a></li>
            <li><a href="<?php echo e(url('subsidiaries/pt-varion-sukses-makmur')); ?>">PT VARION AGRITECH INDONESIA</a></li>
            <li><a href="<?php echo e(url('subsidiaries/pt-varion-sukses-makmur')); ?>">PT VARION AGRO SENTOSA</a></li>
            <li><a href="<?php echo e(url('subsidiaries/pt-varion-sukses-makmur')); ?>">PT VARION CAPITAL MANAGEMENT</a></li>
            <li><a href="<?php echo e(url('subsidiaries/pt-varion-sukses-makmur')); ?>">FUME KOPI INDONESIA - CAFE & RESTO</a></li>
            <li><a href="<?php echo e(url('subsidiaries/pt-varion-sukses-makmur')); ?>">FUME KOPI INDONESIA - CONTAINER PROJECT</a></li>
            <li><img src="<?php echo e(asset('images/logo_black.png')); ?>" alt=""></li>
        </ul>
    </div>
</div>
<?php /**PATH C:\Users\ghass\Documents\Progamming\Work\varion\resources\views/components/presentational/menuMobile.blade.php ENDPATH**/ ?>