
<?php $__env->startSection('content'); ?>
<div class="h_aks1"></div>
<header class="position-relative">
    <?php echo $__env->make('components/presentational/menu',['listMenu'=>$listMenu], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</header>
<main>
    <section class="section__career-first">
        <div class="container">
            <div class="row">
                <div class="col-12 col-lg-5">
                    <h1 class="mb-5"><?php echo e($title); ?></h1>
                    <p class="mb-5"><?php echo e($description); ?></p>
                    <a href="">
                        <ul>
                            <li>VIEW JOB OPENING</li>
                            <li><img src="<?php echo e(asset('/images/right-arrow.svg')); ?>" width="20px" height="20px"/></li>
                        </ul>
                    </a>
                </div>
            </div>
        </div>
        <div class="bg-mainCareerFirst"></div>
    </section>
    
    <section class="section__career-second">
        <img src="<?php echo e(asset('images/carrer.jpg')); ?>" width="100%" alt="">
    </section>
    <section class="section__career-third">
        <div class="container">
            <div class="row">
                <div class="col-12 mb-5r">
                    <h2>OPEN POSITIONS</h2>
                </div>
                <?php $__currentLoopData = $listCareer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 list__career">
                    <div class="row">
                        <div class="list__career-desc col-12 col-lg-6">
                            <h4><?php echo e($item->name); ?></h4>
                            <p><?php echo e($item->description); ?></p>
                        </div>
                        <div class="list__career-status col-12 col-lg-3 d-flex flex-column justify-content-lg-center justify-content-start align-items-start align-items-lg-center">
                            <ul>
                                <li>Status  : <?php echo e($item->status); ?></li>
                                <li>Location  : <?php echo e($item->location); ?></li>
                            </ul>
                        </div>
                        <div class="list__career-join col-12 col-lg-3 d-flex flex-column justify-content-start justify-content-lg-center align-items-start align-items-lg-end">
                            <a class="btn-danger btn btn-join">Join Now</a>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <section class="section__career-contact">
        <?php echo $__env->make('components/presentational/contact',['country'=>$country], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </section>
</main>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('components/layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ghass\Documents\Progamming\Work\varion\resources\views/v_career.blade.php ENDPATH**/ ?>