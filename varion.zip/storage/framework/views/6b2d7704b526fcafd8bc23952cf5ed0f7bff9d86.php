<?php
  header('X-Frame-Options: DENY'); //HTTP 1.1
?>

<?php $__env->startSection('content'); ?>
<div class="h_aks1"></div>
<header class="position-relative">
    <?php echo $__env->make('components/presentational/menu',['listMenu'=>$listMenu], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</header>
<main>
    <section class="section__about-first">
        <iframe src="https://healthmall.medkomtek.net/products/category/suplemen-vitamin" width="300px" height="300px"></iframe>
    </section>  
</main>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('components/layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ghass\Documents\Progamming\Work\varion\resources\views/v_sbk.blade.php ENDPATH**/ ?>