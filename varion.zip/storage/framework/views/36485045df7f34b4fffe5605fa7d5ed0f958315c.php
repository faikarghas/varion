
<?php $__env->startSection('content'); ?>
<header>
    <?php echo $__env->make('components/presentational/menu',['listMenu'=>$listMenu], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="slider__header" page="home">
        <ul class="homeHeaderSlider">
            <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="homeHeaderSlider-item">
                    <div class="left-img"><img src="<?php echo e(asset('images/home1.jpg')); ?>" alt="fume-img1" width="100%">
                        <div class="homeHeaderSlider-item--desc forDesktop">
                            <h1><?php echo $item->description; ?></h1>
                            <div class="learn__button"><a href="<?php echo e(route('home')); ?>">LEARN MORE</a></div>
                        </div>
                    </div>
                    <div class="right-img"><img src="<?php echo e(asset('images/home2.jpg')); ?>" alt="fume-img1" width="100%">
                        <div class="logo_varion">
                            <img class="" src="<?php echo e(asset('images/varion_logo_white.png')); ?>" alt="">
                        </div>
                    </div>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <div class="bg-headerHome"></div>
    <div class="h_aks1"></div>
    <div class="h_aks2"></div>
</header>
<main>
    <section class="sectionHome__subsidiaries">
        <div class="container">
            <div class="row">
                <div class="col-6 col-lg-4 sectionHome__subsidiaries-left">
                    <div class="slider-for">
                        <?php $__currentLoopData = $content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div>
                                <h3>OUR<br/>SUBSIDIARIES</h3>
                                <h4><?php echo e($item->name); ?></h4>
                                <h3 class="text-dark"><?php echo e($item->titleHome); ?></h3>
                                <p class="sectionHome__subsidiaries-desc"><?php echo e($item->shortDescriptionHome); ?></p>
                                <div class="learn__button-dark"><a href="<?php echo e(url('subsidiaries')); ?>/<?php echo e($item->slug); ?>">LEARN MORE</a></div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="col-6 col-lg-8 d-flex align-items-end position-relative sectionHome__subsidiaries-right">
                    <div class="paging__info">
                        <p class="paging__info-curr"></p>
                        <p>/</p>
                        <p class="paging__info-total"></p>
                    </div>
                    <ul class="slider-nav">
                        <?php $__currentLoopData = $content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><img src="<?php echo e(asset('images')); ?>/<?php echo e($item->imageHome); ?>" width="100%" height="360px" alt=""><div class="box_number"><p>0<?php echo e($key + 1); ?>.</p></div></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
        <div class="bg-sliderSub"></div>
        <div class="bg-sliderSub2"></div>
    </section>
    <section class="sectionHome__slider">
        <ul class="homeSectionSlider">
            <li><img src="<?php echo e(asset('images/Varionsuksesmakmur-3.jpg')); ?>" alt="" width="100%" height="100%"></li>
            <li><img src="<?php echo e(asset('images/VarionagritechIndo-4.jpg')); ?>" alt="" width="100%" height="100%"></li>
            <li><img src="<?php echo e(asset('images/VarionAgroSentosa-12.jpg')); ?>" alt="" width="100%" height="100%"></li>
            <li><img src="<?php echo e(asset('images/fume-4.png')); ?>" alt="" width="100%" height="100%"></li>
            <li><img src="<?php echo e(asset('images/VarionagritechIndo-3.jpg')); ?>" alt="" width="100%" height="100%"></li>
        </ul>
    </section>
    <section class="sectionHome__contact">
        <?php echo $__env->make('components/presentational/contact',[
                    'description'=>$descriptionCT,
                    'addressCT'=>$addressCT,
                    'phoneCT'=>$phoneCT,
                    'faxCT'=>$faxCT,
                    'emailCT'=>$emailCT
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </section>
</main>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('components/layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ghass\Documents\Progamming\Work\varion\resources\views/v_home.blade.php ENDPATH**/ ?>