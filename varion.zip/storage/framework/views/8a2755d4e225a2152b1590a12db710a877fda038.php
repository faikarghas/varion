<div class="contact__wrapper">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h3>CONTACT US</h3>
            </div>
            <div class="col-12 col-lg-4 mb-5">
                <p><?php echo e($descriptionCT); ?></p>
            </div>
            <div class="col-12 col-lg-8">
                <div class="contact__wrapper-r">
                    <ul class="contact__wrapper-r-info forDesktop">
                        <li><p><?php echo e($addressCT); ?></p></li>
                        <li><p>PHONE <?php echo e($phoneCT); ?></p></li>
                        <li><p>FAX <?php echo e($faxCT); ?></p></li>
                        <li><p><?php echo e($emailCT); ?></p></li>
                        <img class="loc_img" src="<?php echo e(asset('images/office.svg')); ?>" width="25px" height="25px" alt="">
                    </ul>
                    <form class="contact__wrapper-r-form" action="/contact/form" method="post" accept-charset="utf-8">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <input name="name" class="form-control" type="text" placeholder="YOUR NAME" value="<?php echo e(old('name')); ?>">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <select name="country" class="form-select form-select-sm" aria-label=".form-select-sm example">
                                <option selected>COUNTRY</option>
                                <?php $__currentLoopData = $country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item['name']); ?>"><?php echo e($item['name']); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <input name="email" class="form-control" type="text" placeholder="EMAIL" aria-label="default input example" value="<?php echo e(old('email')); ?>">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <input name="phoneNumber" class="form-control" type="number" placeholder="PHONE NUMER" aria-label="default input example" value="<?php echo e(old('phoneNumber')); ?>">
                            <?php $__errorArgs = ['phoneNumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <button class="btn btn-primary">SEND</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="bg-contact"></div>
</div><?php /**PATH C:\Users\ghass\Documents\Progamming\Work\varion\resources\views/components/presentational/contact.blade.php ENDPATH**/ ?>