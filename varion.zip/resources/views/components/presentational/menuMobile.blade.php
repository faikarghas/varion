<div class="menu__mobileOverlay">
</div>

<div class="menu__mobile forMobile">
    <div class="menu__mobile-search">
        <form action="">
            <input type="text" name="" id="" placeholder="SEARCH...">
        </form>
    </div>
    <div class="menu__mobile-link">
        <ul>
            <li><a href="{{route('about')}}">ABOUT</a></li>
            <li><a href="{{route('career')}}">CAREER</a></li>
            <li><a href="{{route('contact')}}">CONTACT</a></li>
            <li><a href="{{url('subsidiaries/pt-varion-sukses-makmur')}}">PT VARION SUKSES MAKMUR</a></li>
            <li><a href="{{url('subsidiaries/pt-varion-sukses-makmur')}}">PT VARION AGRITECH INDONESIA</a></li>
            <li><a href="{{url('subsidiaries/pt-varion-sukses-makmur')}}">PT VARION AGRO SENTOSA</a></li>
            <li><a href="{{url('subsidiaries/pt-varion-sukses-makmur')}}">PT VARION CAPITAL MANAGEMENT</a></li>
            <li><a href="{{url('subsidiaries/pt-varion-sukses-makmur')}}">FUME KOPI INDONESIA - CAFE & RESTO</a></li>
            <li><a href="{{url('subsidiaries/pt-varion-sukses-makmur')}}">FUME KOPI INDONESIA - CONTAINER PROJECT</a></li>
            <li><img src="{{asset('images/logo_black.png')}}" alt=""></li>
        </ul>
    </div>
</div>
